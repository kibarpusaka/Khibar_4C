package SuratMasuk;

import java.util.*;
import entity.*;
/**
 *
 * @author khibar
 */
public class surat_masuk {
    
    private static List<surat> data = new LinkedList<surat>();
    
    public void addData(surat lp) {
        data.add(lp);
        System.out.println("Selamat Data Anda Telah diSimpan");
    }
    
    public void updateData(surat lp){
        int index = data.indexOf(lp);
        if (index >= 0 ) {
        
        data.set(index, lp);
        System.out.println("Selamat Data Anda Telah diUbah");
        }
    }
    
    public void deleteData(String id){
        int idx = data.indexOf(new surat(id, "", ""));
        if(idx >=0) {
            data.remove(idx);
            System.out.println("Selamat Data Anda Telah diHapus");
        }
    }
    
    public void showAllData() {
        int i=1;
        System.out.println("\nData Dalam Daftar");
        for(surat lp : data) {
            System.out.println("data ke-"+ i++);
            System.out.println("ID : " + lp.getId());
            System.out.println("Nama : " + lp.getNama());
            System.out.println("Jenis Surat : " + lp.setJenis_surat());
        }
    }
}
