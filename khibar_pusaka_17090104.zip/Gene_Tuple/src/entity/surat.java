/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package entity;

/**
 *
 * @author khibar
 */
public class surat {
    
    private String id;
    private String nama;
    private String jenis_surat;
    
    public String getId() {
        return id;
    }
    
    public void setId(String id) {
        this.id = id;
    }
    
    public String getNama() {
        return nama;
    }
    
    public void setNama(String nama) {
        this.nama = nama;
    }
    
    public String setJenis_surat() {
        return jenis_surat;
    }
    
    public void setJenis_Surat(String jenis_surat) {
        this.jenis_surat = jenis_surat;
    }
    
    public surat(String id, String nama, String jenis_surat) {
        this.id = id;
        this.nama = nama;
        this.jenis_surat = jenis_surat;
    }
    
    public boolean equals(Object object) {
        surat temp = (surat) object;
        return id.equals(temp.getId());
    }
}
